import re
import joblib
import gradio as gr
import numpy as np
import tensorflow as tf
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer

#initialize lemmatizer
lemmatizer = WordNetLemmatizer()

#load vectorizer
vectorizer = joblib.load('vectorizer.pkl')

#load model
model = joblib.load('SVMc.pkl')

# class names
class_names = ["Flaged as Fake News. Consider checking sources.", "Likely News."]


def process_predict(headline):
    # into string
    headline = str(headline)

    # remove JS/CSS
    headline = re.sub(r'<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>|<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>', '', headline)

    # remove HTML comments
    headline = re.sub(r'<!--.*?-->', '', headline)

    # remove HTML tags
    headline = re.sub(r'<[^>]+>', '', headline)

    # remove all special characters
    headline = re.sub(r'[^a-zA-Z\s]', ' ', headline)  # Keep only letters and spaces

    # remove numbers
    headline = re.sub(r'\d+', ' ', headline)

    # remove all single characters
    headline = re.sub(r'\b[a-zA-Z]\b', ' ', headline)  # Remove isolated single letters

    # remove single characters from the start
    headline = re.sub(r'^[a-zA-Z]\s+', ' ', headline)

    # remove prefixed 'b'
    headline = re.sub(r'\bb\s+', ' ', headline)

    # removes multiple spaces to keep one
    headline = re.sub(r'\s+', ' ', headline).strip()

    # lowercase
    headline = headline.lower()

    # tokens
    words = headline.split()

    # lemmatize each word
    lemmatized_words = [lemmatizer.lemmatize(word) for word in words]

    # create cleaned headline with lemmatized words
    headline_clean = ' '.join(lemmatized_words)

    # apply TF-IDF transformation
    tfidf_sentence = vectorizer.transform([headline_clean])

    # make prediction
    pred = model.predict(tfidf_sentence)

    # return the corresponding class name
    return class_names[pred[0]]



# Create Gradio interface
interface = gr.Interface(
    fn=process_predict,  # Function to process input and return output
    inputs=gr.Textbox(label="Enter News Headline"),
    outputs=gr.Textbox(label="Advice : "),
    title="Fake News Detector",
    description="Enter a News headline to check its veracity"
)

# Launch the app
interface.launch(share = True)



